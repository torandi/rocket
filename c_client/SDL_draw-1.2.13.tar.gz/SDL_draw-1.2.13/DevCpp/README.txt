Dev-C++ 4.9.9.2 Instructions
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

- First Build "SDL_draw_static.dev"
- Then you can build "sdldrawtest.dev" (exe with SDL_draw static library and SDL.dll)
- At any time you can build "SDL_draw_dynamic.dev" to get "SDL_draw.dll"

- The static and dynamic libraries, and the executable 'sdldrawtest.exe' 
  are in current directory (you need SDL.dll in this directory to run sdldrawtest.exe).

