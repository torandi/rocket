Put here the SDL headers files under a directory 'include',
and the SDL library files under a directory 'lib' (files libSDL.dll.a and libSDLmain.a).
Also put SDL.dll in CodeBlocks main directory.

You can get SDL development files for Windows and "mingw32" from: http://www.libsdl.org/

