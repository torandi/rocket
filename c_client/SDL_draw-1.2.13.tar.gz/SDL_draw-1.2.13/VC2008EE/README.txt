Visual C++ 2008 Express Edition (9.0) Instructions
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

- Open "SDL_draw" solution.
- First Build "SDL_draw_static" project
- Then you can build "sdldrawtest" project (exe with SDL_draw_static library and SDL.dll)
- At any time you can build "SDL_draw_dynamic" project to get "SDL_draw.dll"

- The static and dynamic libraries, and the executable 'sdldrawtest.exe' 
  are in current directory (you need SDL.dll in this directory to run sdldrawtest.exe).

