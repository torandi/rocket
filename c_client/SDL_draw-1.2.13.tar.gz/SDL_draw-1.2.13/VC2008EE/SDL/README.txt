Put here the SDL headers files under a directory 'include',
and the SDL library files under a directory 'lib' (files SDL.lib and SDLmain.lib).
Also put SDL.dll in VC2008EE main directory.

You can get SDL development files for Windows and "VC8" from: http://www.libsdl.org/

